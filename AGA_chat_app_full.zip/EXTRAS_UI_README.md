# إضافات وتحسينات واجهة المستخدم لأجل AGA

اقتراحات سريعة لتجميل واجهة المستخدم:
- استخدم AppBar مخصص بخط أكبر وشعار AGA صغير على اليسار.
- استعمل بطاقات (Card) للمحادثات مع صورة المستخدم وصندوق نص مختصر.
- استخدم مكتبة cached_network_image لتحميل صور الشبكة بكفاءة.
- تصميم المظهر: ألوان أساسية Teal + Accent أفتح (استخدم نظام ألوان Material3 إن رغبت).
- استخدم خطوط عربية مناسبة (مثل 'Cairo' أو 'Tajawal') عبر إضافة إلى pubspec.yaml.

أيقونات التطبيق:
- يمكن توليد أيقونات بأحجام متعددة عبر https://appicon.co أو Android Asset Studio.
- ضع الصور في android/app/src/main/res/mipmap-*/ic_launcher.png وic_launcher_foreground.png

قواعد Firestore (نموذج):
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    match /chats/{chatId} {
      allow read: if request.auth != null && request.auth.uid in resource.data.members;
      allow write: if request.auth != null && request.auth.uid in request.resource.data.members;
      match /messages/{msgId} {
        allow read, write: if request.auth != null && request.auth.uid in get(/databases/$(database)/documents/chats/$(chatId)).data.members;
      }
    }
  }
}
```


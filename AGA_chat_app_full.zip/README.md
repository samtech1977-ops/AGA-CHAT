# AGA Chat - Flutter + Firebase (Android)

نسخة جاهزة مبدئية لتطبيق الدردشة "AGA" للتشغيل على Android.

## ماذا يحتوي هذا المشروع
- بنية Flutter أساسية (ملفات `lib/` الرئيسية)
- تسجيل وتفعيل عبر البريد الإلكتروني (Firebase Email Verification)
- دردشات فردية (نموذج بسيط: نص + رفع وسائط)
- رفع الوسائط إلى Firebase Storage (مبدأي)
- إعدادات FCM موضوعة كمكان للتكامل لاحقاً

> ملاحظة مهمة: **لا يحتوي هذا الأرشيف على ملف google-services.json**. تحتاج لإنشاء مشروع Firebase خاص بك ثم تنزيل `google-services.json` ووضعه في `android/app/`.

## خطوات الإعداد
1. ثبت Flutter SDK وAndroid Studio أو استخدم VS Code.
2. إنشاء مشروع Firebase جديد باسم مثلاً "AGA Chat".
3. فعل Authentication (Email/Password), Firestore, Storage, Cloud Messaging.
4. قم بتنزيل `google-services.json` وضعه داخل `android/app/`.
5. افتح الطرفية في مجلد المشروع وشغل:
   ```
   flutter pub get
   flutter run
   ```
6. إذا ظهرت مشاكل في نسخ الحزم، عدل أرقام الإصدارات في `pubspec.yaml`.

## ملفات مهمة
- `lib/main.dart` - نقطة البداية وAuth wrapper
- `lib/screens/login_screen.dart` - تسجيل/دخول
- `lib/screens/verify_email_screen.dart` - شاشة التحقق من الإيميل
- `lib/screens/chats_list_screen.dart` - قائمة الدردشات
- `lib/screens/chat_screen.dart` - المحادثة الفردية
- `lib/screens/profile_screen.dart` - ملف المستخدم
- `lib/services/*` - خدمات مصغرة (auth, firestore, storage, fcm)

## AndroidManifest
في `android/app/src/main/AndroidManifest.xml` تأكد من وجود:
```xml
<application
    android:label="AGA"
    android:icon="@mipmap/ic_launcher"
    android:usesCleartextTraffic="true">
```

## لاحقاً
- إضافة Cloud Functions لإرسال إشعارات عند رسالة جديدة.
- تحسين قواعد Firestore لأمن أفضل.
- إضافة ميزة مجموعات وstatus.

بالتوفيق! إذا تريد، أستطيع الآن:
- إضافة **Cloud Function** كاملة لإرسال كود تحقق عبر البريد (SendGrid).
- تجهيز أيقونات وشعار `AGA`.
- رفع نسخة معدّة بالكامل مع `google-services.json` لو أعطيتني الملف (إرفاقه هنا).


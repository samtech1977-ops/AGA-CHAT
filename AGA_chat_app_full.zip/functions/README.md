# Firebase Cloud Functions for AGA

This folder contains two callable functions:

1. sendEmailCode (data: { email })
   - Generates a 6-digit code
   - Stores it in Firestore at `emailCodes/{email}` with expiry
   - Sends email using SendGrid

2. verifyEmailCode (data: { email, code })
   - Verifies the code stored in Firestore

## Setup

1. Install Firebase CLI and initialize functions:
   ```
   cd functions
   npm install
   firebase login
   firebase init functions
   ```

2. Add SendGrid API key to functions config:
   ```
   firebase functions:config:set sendgrid.key="YOUR_SENDGRID_KEY" sendgrid.from="no-reply@aga.app"
   ```

3. Deploy:
   ```
   firebase deploy --only functions
   ```

Security note: For production, avoid storing codes in plaintext. Use hashed codes and rate limit requests.

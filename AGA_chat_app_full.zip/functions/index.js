const functions = require('firebase-functions');
const admin = require('firebase-admin');
const sgMail = require('@sendgrid/mail');

admin.initializeApp();
sgMail.setApiKey(functions.config().sendgrid.key);

/**
 * Callable function: sendEmailCode
 * Data: { email: string }
 * Generates a 6-digit code, stores it in Firestore under 'emailCodes/{email}',
 * and sends it via SendGrid. Code expires in 10 minutes.
 */
exports.sendEmailCode = functions.https.onCall(async (data, context) => {
  const email = data.email;
  if (!email) {
    throw new functions.https.HttpsError('invalid-argument', 'Email required');
  }

  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const expires = Date.now() + 10 * 60 * 1000; // 10 minutes

  // Store code (hashed in production for better security)
  await admin.firestore().collection('emailCodes').doc(email).set({ code, expires });

  const msg = {
    to: email,
    from: functions.config().sendgrid.from || 'no-reply@aga.app',
    subject: 'AGA - رمز التحقق',
    text: `رمز التحقق لتطبيق AGA: ${code}. صالح لمدة 10 دقائق.`,
    html: `<p>رمز التحقق لتطبيق <strong>AGA</strong>: <strong>${code}</strong>.</p><p>صالح لمدة 10 دقائق.</p>`
  };

  await sgMail.send(msg);
  return { result: 'sent' };
});

/**
 * Callable function: verifyEmailCode
 * Data: { email: string, code: string }
 * Verifies the code and returns success boolean.
 */
exports.verifyEmailCode = functions.https.onCall(async (data, context) => {
  const email = data.email;
  const code = data.code;
  if (!email || !code) {
    throw new functions.https.HttpsError('invalid-argument', 'Email and code required');
  }

  const doc = await admin.firestore().collection('emailCodes').doc(email).get();
  if (!doc.exists) {
    return { verified: false, reason: 'not_found' };
  }
  const dataDoc = doc.data();
  if (Date.now() > dataDoc.expires) {
    return { verified: false, reason: 'expired' };
  }
  if (dataDoc.code !== code) {
    return { verified: false, reason: 'wrong_code' };
  }

  // Optionally: create user record or mark verified
  await admin.firestore().collection('emailCodes').doc(email).delete();
  return { verified: true };
});

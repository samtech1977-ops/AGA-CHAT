import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:uuid/uuid.dart';

class ChatScreen extends StatefulWidget {
  final String chatId;
  ChatScreen({required this.chatId});
  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _txt = TextEditingController();
  final uid = FirebaseAuth.instance.currentUser!.uid;

  void sendText() async {
    final text = _txt.text.trim();
    if (text.isEmpty) return;
    final msgId = Uuid().v4();
    final ref = FirebaseFirestore.instance
        .collection('chats')
        .doc(widget.chatId)
        .collection('messages')
        .doc(msgId);
    await ref.set({
      'from': uid,
      'text': text,
      'type': 'text',
      'timestamp': FieldValue.serverTimestamp(),
    });
    await FirebaseFirestore.instance.collection('chats').doc(widget.chatId).update({
      'lastMessage': text,
      'lastTime': FieldValue.serverTimestamp(),
    });
    _txt.clear();
  }

  @override
  Widget build(BuildContext context) {
    final messagesRef = FirebaseFirestore.instance.collection('chats').doc(widget.chatId).collection('messages').orderBy('timestamp');
    return Scaffold(
      appBar: AppBar(title: Text('محادثة')),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: messagesRef.snapshots(),
              builder: (context, snap) {
                if (!snap.hasData) return Center(child: CircularProgressIndicator());
                final docs = snap.data!.docs;
                return ListView.builder(
                  itemCount: docs.length,
                  itemBuilder: (context, i) {
                    final data = docs[i].data() as Map<String, dynamic>;
                    final isMe = data['from'] == uid;
                    return Align(
                      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        padding: EdgeInsets.all(10),
                        margin: EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                        decoration: BoxDecoration(color: isMe ? Colors.teal[200] : Colors.grey[300], borderRadius: BorderRadius.circular(8)),
                        child: Text(data['text'] ?? ''),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          SafeArea(
            child: Row(
              children: [
                IconButton(onPressed: () {}, icon: Icon(Icons.photo)),
                Expanded(child: TextField(controller: _txt)),
                IconButton(onPressed: sendText, icon: Icon(Icons.send)),
              ],
            ),
          )
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import 'package:firebase_auth/firebase_auth.dart';

class CreateGroupScreen extends StatefulWidget {
  @override
  _CreateGroupScreenState createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen> {
  final _nameC = TextEditingController();
  final _membersC = TextEditingController(); // comma-separated emails
  bool loading = false;

  Future<void> createGroup() async {
    setState(() => loading = true);
    final id = Uuid().v4();
    final currentUid = FirebaseAuth.instance.currentUser!.uid;
    final membersEmails = _membersC.text.split(',').map((s) => s.trim()).where((s) => s.isNotEmpty).toList();
    // In production, resolve emails to UIDs. Here we store emails as members list for demo.
    await FirebaseFirestore.instance.collection('chats').doc(id).set({
      'isGroup': true,
      'title': _nameC.text.trim(),
      'membersEmails': membersEmails,
      'owner': currentUid,
      'lastMessage': '',
      'lastTime': FieldValue.serverTimestamp(),
    });
    setState(() => loading = false);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('إنشاء مجموعة - AGA')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: _nameC, decoration: InputDecoration(labelText: 'اسم المجموعة')),
            TextField(controller: _membersC, decoration: InputDecoration(labelText: 'أيميلات الأعضاء (مفصولة بفواصل)')),
            SizedBox(height: 12),
            ElevatedButton(onPressed: createGroup, child: Text('إنشاء')),
            if (loading) CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'verify_email_screen.dart';
import 'chats_list_screen.dart';

class LoginScreen extends StatefulWidget {
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailC = TextEditingController();
  final _passC = TextEditingController();
  bool loading = false;
  final _auth = FirebaseAuth.instance;

  void signUp() async {
    setState(() => loading = true);
    try {
      final cred = await _auth.createUserWithEmailAndPassword(
        email: _emailC.text.trim(),
        password: _passC.text.trim(),
      );
      await cred.user!.sendEmailVerification();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تم إرسال بريد التحقق. افتح صندوق البريد للتفعيل.')),
      );
      setState(() => loading = false);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => VerifyEmailScreen()),
      );
    } on FirebaseAuthException catch (e) {
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'خطأ')));
    }
  }

  void signIn() async {
    setState(() => loading = true);
    try {
      await _auth.signInWithEmailAndPassword(
        email: _emailC.text.trim(),
        password: _passC.text.trim(),
      );
      setState(() => loading = false);
      if (_auth.currentUser != null && !_auth.currentUser!.emailVerified) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => VerifyEmailScreen()));
      } else {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ChatsListScreen()));
      }
    } on FirebaseAuthException catch (e) {
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'خطأ')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AGA - تسجيل / تسجيل دخول')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: _emailC, decoration: InputDecoration(labelText: 'البريد الإلكتروني')),
            TextField(controller: _passC, decoration: InputDecoration(labelText: 'كلمة المرور'), obscureText: true),
            SizedBox(height: 12),
            if (loading) CircularProgressIndicator(),
            ElevatedButton(onPressed: signIn, child: Text('تسجيل دخول')),
            OutlinedButton(onPressed: signUp, child: Text('إنشاء حساب')),
          ],
        ),
      ),
    );
  }
}

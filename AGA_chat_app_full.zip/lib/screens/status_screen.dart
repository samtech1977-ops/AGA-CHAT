import 'package:flutter/material.dart';

class StatusScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الحالات - AGA')),
      body: Center(child: Text('نموذج للحالات (Status/Stories) - يمكن إضافة رفع صور وفترات صلاحية')),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add_a_photo),
        onPressed: () {
          // افتح كاميرا أو الاستديو لرفع حالة جديدة
        },
      ),
    );
  }
}

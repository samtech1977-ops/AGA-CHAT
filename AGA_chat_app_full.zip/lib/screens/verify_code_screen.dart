import 'package:flutter/material.dart';
import 'package:cloud_functions/cloud_functions.dart';
import '../services/functions_service.dart';
import 'login_screen.dart';
import 'chats_list_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';

class VerifyCodeScreen extends StatefulWidget {
  final String email;
  VerifyCodeScreen({required this.email});
  @override
  _VerifyCodeScreenState createState() => _VerifyCodeScreenState();
}

class _VerifyCodeScreenState extends State<VerifyCodeScreen> {
  final _codeC = TextEditingController();
  bool loading = false;
  final FunctionsService funcs = FunctionsService();

  Future<void> resend() async {
    setState(() => loading = true);
    try {
      await funcs.sendCode(widget.email);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم إرسال كود التحقق إلى البريد.')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('خطأ أثناء الإرسال.')));
    } finally {
      setState(() => loading = false);
    }
  }

  Future<void> verify() async {
    setState(() => loading = true);
    try {
      final ok = await funcs.verifyCode(widget.email, _codeC.text.trim());
      if (ok) {
        // Optionally create Firebase Auth user with email only (anonymous password) or
        // use existing auth flow. Here we'll create a user with a random password if not exists.
        try {
          final users = await FirebaseAuth.instance.fetchSignInMethodsForEmail(widget.email);
          if (users.isEmpty) {
            // create a user with a temporary password
            final userCred = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: widget.email, password: 'AGA_temp_1234');
            // mark as verified? Firebase Auth doesn't allow setting emailVerified client-side.
          }
        } catch (e) {
          // ignore creation errors for now
        }
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ChatsListScreen()));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('رمز خاطئ أو منتهي الصلاحية.')));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('خطأ أثناء التحقق.')));
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    // send code initially
    WidgetsBinding.instance.addPostFrameCallback((_) => resend());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('تحقق بالكود - AGA')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text('أدخل رمز التحقق المرسل إلى ${widget.email}'),
            TextField(controller: _codeC, decoration: InputDecoration(labelText: 'كود التحقق')),
            SizedBox(height: 12),
            ElevatedButton(onPressed: verify, child: Text('تحقق')),
            TextButton(onPressed: resend, child: Text('إعادة إرسال الكود')),
            if (loading) CircularProgressIndicator(),
            TextButton(onPressed: () async { await FirebaseAuth.instance.signOut(); Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => LoginScreen())); }, child: Text('تسجيل الخروج')),
          ],
        ),
      ),
    );
  }
}

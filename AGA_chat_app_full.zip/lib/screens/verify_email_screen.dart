import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'login_screen.dart';
import 'chats_list_screen.dart';

class VerifyEmailScreen extends StatefulWidget {
  @override
  _VerifyEmailScreenState createState() => _VerifyEmailScreenState();
}

class _VerifyEmailScreenState extends State<VerifyEmailScreen> {
  final _auth = FirebaseAuth.instance;
  bool isVerified = false;
  bool loading = false;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final user = _auth.currentUser;
    await user?.reload();
    setState(() {
      isVerified = user?.emailVerified ?? false;
    });
    if (isVerified) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ChatsListScreen()));
    }
  }

  Future<void> resend() async {
    setState(() => loading = true);
    try {
      await _auth.currentUser?.sendEmailVerification();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم إعادة إرسال رابط التحقق.')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('خطأ أثناء الإرسال.')));
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تأكيد البريد - AGA')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('يرجى التحقق من بريدك الإلكتروني والضغط على رابط التفعيل.'),
            SizedBox(height: 12),
            ElevatedButton(onPressed: _check, child: Text('تحقق الآن')),
            TextButton(onPressed: resend, child: Text('إعادة إرسال رابط التفعيل')),
            TextButton(
              onPressed: () async {
                await _auth.signOut();
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => LoginScreen()));
              },
              child: Text('تسجيل الخروج'),
            ),
            if (loading) CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}

import 'package:firebase_messaging/firebase_messaging.dart';

class FCMService {
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;

  Future<String?> getToken() async {
    return await _fcm.getToken();
  }

  // Configure onMessage / onBackground handlers in main.dart or a dedicated handler.
}

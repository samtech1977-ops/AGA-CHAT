import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> createChat(String chatId, Map<String, dynamic> data) async {
    await _db.collection('chats').doc(chatId).set(data);
  }

  Future<void> sendMessage(String chatId, String messageId, Map<String, dynamic> data) async {
    await _db.collection('chats').doc(chatId).collection('messages').doc(messageId).set(data);
    await _db.collection('chats').doc(chatId).update({
      'lastMessage': data['text'] ?? '',
      'lastTime': FieldValue.serverTimestamp(),
    });
  }
}

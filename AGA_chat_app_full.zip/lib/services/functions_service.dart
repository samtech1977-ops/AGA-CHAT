import 'package:cloud_functions/cloud_functions.dart';

class FunctionsService {
  final HttpsCallable sendEmailCode = FirebaseFunctions.instance.httpsCallable('sendEmailCode');
  final HttpsCallable verifyEmailCode = FirebaseFunctions.instance.httpsCallable('verifyEmailCode');

  Future<void> sendCode(String email) async {
    await sendEmailCode.call({'email': email});
  }

  Future<bool> verifyCode(String email, String code) async {
    final res = await verifyEmailCode.call({'email': email, 'code': code});
    final data = res.data as Map<String, dynamic>;
    return data['verified'] == true;
  }
}
